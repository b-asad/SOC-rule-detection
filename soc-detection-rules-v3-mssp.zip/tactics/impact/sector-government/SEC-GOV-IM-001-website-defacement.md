# SEC-GOV-IM-001 — Government: Website Defacement / Public Service Disruption

| Field | Value |
|-------|-------|
| **Rule ID** | `SEC-GOV-IM-001` |
| **MITRE Technique** | T1491.002 — Defacement: External Defacement |
| **Sector** | Government |
| **Severity** | **High** | **Priority** | **P1** |
| **MS Tools** | Sentinel · Defender for Endpoint |
| **Log Source** | `DeviceFileEvents` (MDE) · Azure WAF Logs |

## Description
Modification of public-facing government website files outside of an approved deployment pipeline. Hacktivists and nation-state actors target government websites for propaganda, public confidence damage, and intelligence operations. Reputational impact for central government is significant.

## Microsoft Sentinel KQL
```kql
// SEC-GOV-IM-001 | Frequency: 5m | Lookback: 5m
DeviceFileEvents
| where TimeGenerated >= ago(5m)
| where FolderPath has_any ("wwwroot","htdocs","public_html","inetpub","webroot","gov.uk")
| where FileName has_any (".html",".php",".js",".aspx",".htm",".css")
| where ActionType in ("FileCreated","FileModified")
| where InitiatingProcessFileName !in~ ("w3wp.exe","iis","deploy_agent","git","node")
| project TimeGenerated, DeviceName, FileName, FolderPath, SHA256, InitiatingProcessFileName, AccountName
| extend AlertTitle = strcat("Government Website File Modified: ", FileName)
```

## Response Actions
- [ ] Take affected web server offline if defacement confirmed
- [ ] Restore from last known-good deployment
- [ ] Notify Communications team for public statement readiness
- [ ] Notify NCSC via report.ncsc.gov.uk

## References - [MITRE T1491.002](https://attack.mitre.org/techniques/T1491/002/)
