# SEC-EDU-CA-001 — Education: Student/Staff Credential Stuffing Attack

| Field | Value |
|-------|-------|
| **Rule ID** | `SEC-EDU-CA-001` |
| **MITRE Technique** | T1110.004 — Credential Stuffing |
| **Sector** | Education |
| **Severity** | **High** | **Priority** | **P1** |
| **MS Tools** | Sentinel · Defender for Cloud Apps |
| **Log Source** | `SigninLogs` · Azure WAF Logs |

## Description
Credential stuffing against university or school student/staff login portals using breached credentials. Education sector login pages are targeted for access to student PII, grade manipulation, research data, and financial aid fraud. Large student cohorts mean large attack surfaces.

## Microsoft Sentinel KQL
```kql
// SEC-EDU-CA-001 | Frequency: 10m | Lookback: 10m
SigninLogs
| where TimeGenerated >= ago(10m) and ResultType != "0"
| summarize FailCount=count(), UniqueAccounts=dcount(UserPrincipalName)
    by IPAddress, tostring(LocationDetails.countryOrRegion)
| where FailCount > 50 and UniqueAccounts > 10
| extend AlertTitle = strcat("Education Portal Credential Stuffing from ", IPAddress)
| extend JISCObligation = "Notify JISC Cyber Security team if significant attack"
```

## Response Actions
- [ ] Block attacking IPs at WAF and Conditional Access
- [ ] Force password reset for successfully authenticated accounts from attacking IPs
- [ ] Enable CAPTCHA on student/staff login portal
- [ ] Notify JISC Cyber Security team

## References - [MITRE T1110.004](https://attack.mitre.org/techniques/T1110/004/)
