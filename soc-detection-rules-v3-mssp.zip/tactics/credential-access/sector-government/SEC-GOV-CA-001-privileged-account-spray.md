# SEC-GOV-CA-001 — Government: Password Spray Against Privileged Accounts

| Field | Value |
|-------|-------|
| **Rule ID** | `SEC-GOV-CA-001` |
| **MITRE Technique** | T1110.003 — Password Spraying |
| **Sector** | Government |
| **Severity** | **Critical** | **Priority** | **P1** |
| **MS Tools** | Sentinel · Defender for Identity · Defender XDR |
| **Log Source** | `SigninLogs` · `IdentityLogonEvents` (MDI) |

## Description
Password spray specifically targeting senior civil servant or privileged government accounts. Nation-state actors (APT28, APT29, APT40) frequently use spray attacks against government organisations, prioritising accounts with access to policy documents, diplomatic communications, or classified materials.

## Microsoft Sentinel KQL
```kql
// SEC-GOV-CA-001 | Frequency: 10m | Lookback: 10m
let PrivilegedUsers = (_GetWatchlist('PrivilegedGovAccounts') | project SearchKey);
SigninLogs
| where TimeGenerated >= ago(10m) and ResultType != "0"
| where UserPrincipalName in~ (PrivilegedUsers)
    or UserPrincipalName has_any ("minister","permanent","deputy","director general","scs")
| summarize FailCount=count(), UniqueAccounts=dcount(UserPrincipalName)
    by IPAddress, tostring(LocationDetails.countryOrRegion)
| where FailCount > 5
| extend AlertTitle = strcat("Gov Privileged Account Spray from ", IPAddress)
| extend NCSObligation = "Report to NCSC if nation-state attribution suspected"
```

## Response Actions
- [ ] Block attacking IP in Conditional Access
- [ ] Reset passwords for targeted privileged accounts
- [ ] Notify Departmental Security Officer (DSO)
- [ ] Report to NCSC if attack pattern consistent with nation-state

## References - [MITRE T1110.003](https://attack.mitre.org/techniques/T1110/003/)
