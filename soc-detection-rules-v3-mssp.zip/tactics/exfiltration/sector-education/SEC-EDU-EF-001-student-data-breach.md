# SEC-EDU-EF-001 — Education: Student PII Exfiltration

| Field | Value |
|-------|-------|
| **Rule ID** | `SEC-EDU-EF-001` |
| **MITRE Technique** | T1048 — Exfiltration Over Alternative Protocol |
| **Sector** | Education |
| **Severity** | **High** | **Priority** | **P1** |
| **MS Tools** | Sentinel · Defender for Cloud Apps |
| **Log Source** | `CommonSecurityLog` (Firewall) |

## Description
Upload of student record data (name, DOB, address, grades, financial information) to external services. Student PII is a UK GDPR obligation — any confirmed breach requires ICO notification within 72 hours.

## Microsoft Sentinel KQL
```kql
// SEC-EDU-EF-001 | Frequency: 15m | Lookback: 1h
CommonSecurityLog
| where TimeGenerated >= ago(1h)
| where DeviceAction !in ("deny","block","drop")
| where DestinationHostName has_any ("dropbox","wetransfer","drive.google","mega.nz","box.com")
| where SentBytes > 5000000  // > 5MB — typical for student record exports
| project TimeGenerated, SourceIP, DeviceName, DestinationHostName, SentBytes
| extend AlertTitle = strcat("Large Upload to External Service from ", DeviceName)
| extend GDPRObligation = "UK GDPR Article 33: Notify ICO within 72h if student data confirmed exfiltrated"
```

## Response Actions
- [ ] Block personal cloud storage at network egress
- [ ] Notify DPO and assess ICO notification (72h)
- [ ] Notify affected students if their data was exfiltrated

## References - [MITRE T1048](https://attack.mitre.org/techniques/T1048/)
