# SEC-HC-EF-001 — Healthcare: Medical Data Uploaded to External Service

| Field | Value |
|-------|-------|
| **Rule ID** | `SEC-HC-EF-001` |
| **MITRE Technique** | T1567 — Exfiltration to Cloud Service |
| **Sector** | Healthcare |
| **Severity** | **High** | **Priority** | **P1** |
| **MS Tools** | Sentinel · Defender for Cloud Apps · Defender for Endpoint |
| **Log Source** | `CommonSecurityLog` (Proxy/Firewall) · `CloudAppEvents` (MCAS) |

## Description
Upload of clinical or patient data files to personal cloud storage (Dropbox, Google Drive, WeTransfer, OneDrive personal). Under the Caldicott Principles and NHS DSPT, patient data must not leave approved NHS/clinical systems without explicit governance approval.

## Microsoft Sentinel KQL
```kql
// SEC-HC-EF-001 | Frequency: 15m | Lookback: 1h
DeviceNetworkEvents
| where TimeGenerated >= ago(1h)
| where RemoteUrl has_any ("dropbox.com","wetransfer.com","drive.google.com","mega.nz","box.com","mediafire.com","sendspace.com")
| where BytesSent > 1000000  // > 1MB upload
| where InitiatingProcessFileName in~ ("WINWORD.EXE","EXCEL.EXE","POWERPNT.EXE","explorer.exe","chrome.exe","msedge.exe","firefox.exe")
| project TimeGenerated, DeviceName, AccountName, RemoteUrl, BytesSent, InitiatingProcessFileName
| extend AlertTitle = strcat("Clinical Data Upload to ", RemoteUrl, " from ", DeviceName)
| extend CaldicottBreach = "Potential breach of Caldicott Principles 2 and 3"
```

## Response Actions
- [ ] Block personal cloud storage at proxy/firewall for clinical hosts
- [ ] Notify Caldicott Guardian and DPO
- [ ] Retrieve and assess what files were uploaded

## References - [MITRE T1567](https://attack.mitre.org/techniques/T1567/)
