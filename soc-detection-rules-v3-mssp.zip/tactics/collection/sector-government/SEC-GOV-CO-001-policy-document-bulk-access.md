# SEC-GOV-CO-001 — Government: Bulk Policy Document Access

| Field | Value |
|-------|-------|
| **Rule ID** | `SEC-GOV-CO-001` |
| **MITRE Technique** | T1213 — Data from Information Repositories |
| **Sector** | Government |
| **Severity** | **High** | **Priority** | **P1** |
| **MS Tools** | Sentinel · Defender for Cloud Apps |
| **Log Source** | `OfficeActivity` |

## Description
Bulk access to policy documents, ministerial briefings, or cabinet papers from SharePoint. Nation-state espionage actors prioritise government document repositories for intelligence collection on policy positions, diplomatic strategies, and cabinet decisions.

## Microsoft Sentinel KQL
```kql
// SEC-GOV-CO-001 | Frequency: 15m | Lookback: 1h
OfficeActivity
| where TimeGenerated >= ago(1h)
| where Operation in ("FileDownloaded","FileCopied","FileAccessed")
| where SourceFileName has_any ("policy","briefing","cabinet","minister","strategy","classified","restricted","sensitive","OFFICIAL")
    or Site_Url has_any ("policy","cabinet","minister","briefing","strategy","restricted")
| summarize FileCount=count(), UniqueFiles=dcount(SourceFileName)
    by UserId, ClientIP
| where FileCount > 10
| extend AlertTitle = strcat("Gov Policy Document Bulk Access by ", UserId)
```

## Response Actions
- [ ] Revoke access pending investigation
- [ ] Notify DSO and SIRO
- [ ] Report to NCSC if nation-state indicators present

## References - [MITRE T1213](https://attack.mitre.org/techniques/T1213/)
