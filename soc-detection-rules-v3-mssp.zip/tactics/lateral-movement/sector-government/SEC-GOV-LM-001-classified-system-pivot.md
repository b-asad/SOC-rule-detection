# SEC-GOV-LM-001 — Government: Lateral Movement Toward Classified/Restricted Systems

| Field | Value |
|-------|-------|
| **Rule ID** | `SEC-GOV-LM-001` |
| **MITRE Technique** | T1021 — Remote Services |
| **Sector** | Government |
| **Severity** | **Critical** | **Priority** | **P1** |
| **MS Tools** | Sentinel · Defender for Identity |
| **Log Source** | `IdentityLogonEvents` (MDI) · Firewall logs |

## Description
Authentication or connection attempt from a standard IT host toward hosts tagged as restricted or sensitive government systems. Nation-state espionage campaigns specifically target lateral movement into systems holding policy documents, cabinet communications, or intelligence material.

## Microsoft Sentinel KQL
```kql
// SEC-GOV-LM-001 | Frequency: 5m | Lookback: 5m
let RestrictedHosts = (_GetWatchlist('RestrictedGovSystems') | project SearchKey);
IdentityLogonEvents
| where TimeGenerated >= ago(5m)
| where ActionType == "LogonSuccess"
| where DestinationDeviceName in~ (RestrictedHosts)
    or DestinationDeviceName has_any ("policy","cabinet","minister","restricted","sensitive","classified")
| where not(DeviceName in~ (RestrictedHosts))
| project TimeGenerated, AccountName, DeviceName, DestinationDeviceName, Protocol
| extend AlertTitle = strcat("Access to Restricted Gov System: ", DestinationDeviceName)
| extend NCSObligation = "Report to NCSC via report.ncsc.gov.uk"
```

## Response Actions
- [ ] Isolate both hosts
- [ ] Notify Departmental Security Officer and SIRO immediately
- [ ] Report to NCSC — [report.ncsc.gov.uk](https://report.ncsc.gov.uk)

## References - [MITRE T1021](https://attack.mitre.org/techniques/T1021/)
