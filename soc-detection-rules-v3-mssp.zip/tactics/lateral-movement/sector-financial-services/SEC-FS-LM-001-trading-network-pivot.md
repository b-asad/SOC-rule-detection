# SEC-FS-LM-001 — Financial Services: Lateral Movement into Trading Network

| Field | Value |
|-------|-------|
| **Rule ID** | `SEC-FS-LM-001` |
| **MITRE Technique** | T1550.002 — Pass the Hash |
| **Sector** | Financial Services |
| **Severity** | **Critical** | **Priority** | **P1** |
| **MS Tools** | Sentinel · Defender for Identity |
| **Log Source** | `IdentityLogonEvents` (MDI) |

## Description
NTLM authentication from a standard IT network host to a trading network or financial system host — a network boundary violation. Segmentation between IT and trading networks is a core financial services security control; any pivot across this boundary must be treated as Critical.

## Microsoft Sentinel KQL
```kql
// SEC-FS-LM-001 | Frequency: 5m | Lookback: 5m
let TradingHosts = (_GetWatchlist('TradingNetworkHosts') | project SearchKey);
IdentityLogonEvents
| where TimeGenerated >= ago(5m)
| where ActionType == "LogonSuccess" and Protocol == "Ntlm"
| where DestinationDeviceName in~ (TradingHosts)
    or DestinationDeviceName has_any ("trading","bloomberg","murex","fidessa","fix","settlement","clearing")
| where not(DeviceName in~ (TradingHosts))
| project TimeGenerated, AccountName, DeviceName, DestinationDeviceName, Protocol
| extend AlertTitle = strcat("IT-to-Trading-Network Pivot: ", DeviceName, " -> ", DestinationDeviceName)
```

## Response Actions
- [ ] Isolate both source and destination hosts
- [ ] Notify Head of Technology Risk and Compliance
- [ ] Assess trading platform integrity — were any orders affected?

## References - [MITRE T1550.002](https://attack.mitre.org/techniques/T1550/002/)
