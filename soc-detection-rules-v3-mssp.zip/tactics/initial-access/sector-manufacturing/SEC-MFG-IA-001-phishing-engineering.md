# SEC-MFG-IA-001 — Manufacturing: Phishing Targeting Engineering/OT Staff

| Field | Value |
|-------|-------|
| **Rule ID** | `SEC-MFG-IA-001` |
| **MITRE Technique** | T1566.001 — Spearphishing Attachment |
| **Sector** | Manufacturing |
| **Severity** | **High** | **Priority** | **P1** |
| **MS Tools** | Sentinel · Defender for Office 365 |
| **Log Source** | `EmailEvents` · `DeviceProcessEvents` (MDE) |

## Description
Phishing targeting manufacturing engineers, OT operators, and production managers. Engineers often have access to OT engineering workstations, PLC configuration software, and SCADA historian databases. A compromised engineering account can be used to pivot to OT systems (see SEC-MFG-LM-001).

## Microsoft Sentinel KQL
```kql
// SEC-MFG-IA-001 | Frequency: 5m | Lookback: 1h
let EngineeringKeywords = dynamic(["PLC","SCADA","HMI","AutoCAD","SolidWorks","engineering specification","production","maintenance schedule","factory","plant"]);
EmailEvents
| where TimeGenerated >= ago(1h) and DeliveryAction != "Blocked"
| where (Subject has_any (EngineeringKeywords) or AttachmentCount > 0) and ThreatTypes != ""
| where RecipientEmailAddress has_any ("engineer","operations","maintenance","plant","production","ot","scada")
| project TimeGenerated, RecipientEmailAddress, SenderFromAddress, Subject, ThreatTypes
| extend AlertTitle = strcat("Engineering Staff Phishing: ", Subject)
| extend OTRisk = "Compromised engineering account may enable OT pivot (SEC-MFG-LM-001)"
```

## Response Actions
- [ ] Block sender domain in MDO
- [ ] Check device for GEN-IA-001 macro execution
- [ ] Notify OT Security team — isolate OT access if account compromised

## References - [MITRE T1566.001](https://attack.mitre.org/techniques/T1566/001/)
