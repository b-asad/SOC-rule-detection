# SEC-EDU-IA-001 — Education: Phishing Targeting Student/Staff Portals

| Field | Value |
|-------|-------|
| **Rule ID** | `SEC-EDU-IA-001` |
| **MITRE Technique** | T1566.001 — Spearphishing Attachment |
| **Sector** | Education |
| **Severity** | **High** | **Priority** | **P1** |
| **MS Tools** | Sentinel · Defender for Office 365 |
| **Log Source** | `EmailEvents` · `DeviceProcessEvents` (MDE) |

## Description
Phishing campaigns targeting universities and schools exploit open mail relays, publicly listed student email addresses, and low security awareness. Common themes: financial aid notices, IT security alerts, exam results. Ransomware groups specifically target education for high ransom payment pressure around exam periods.

## Microsoft Sentinel KQL
```kql
// SEC-EDU-IA-001 | Frequency: 5m | Lookback: 1h
let EduKeywords = dynamic(["financial aid","student loan","exam result","library fine","IT password","tuition fee","scholarship","bursary","UCAS"]);
EmailEvents
| where TimeGenerated >= ago(1h) and DeliveryAction != "Blocked"
| where Subject has_any (EduKeywords) and ThreatTypes != ""
| where RecipientEmailAddress has_any (".ac.uk",".edu","university","college","school")
| project TimeGenerated, RecipientEmailAddress, SenderFromAddress, Subject, ThreatTypes, DeliveryAction
| extend AlertTitle = strcat("Education Phishing: ", Subject)
```

## Response Actions
- [ ] Block sender domain in MDO
- [ ] Notify IT Security team and University CISO
- [ ] Issue phishing warning to affected student/staff cohort

## References - [MITRE T1566.001](https://attack.mitre.org/techniques/T1566/001/)
