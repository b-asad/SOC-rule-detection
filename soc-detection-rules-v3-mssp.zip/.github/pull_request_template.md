## Detection Rule Pull Request

**Rule ID(s):** <!-- e.g. GEN-IA-003 -->
**Type:** <!-- New Rule | Update | False Positive Fix | Tuning | Sector Addition -->
**Sector:** <!-- Generic | Retail | Healthcare | Financial Services | Government | Education | Manufacturing | Legal | Technology | Energy & Utilities -->
**Tactic:** <!-- e.g. Initial Access -->

---

### Summary of Changes
<!-- What was added or changed and why? Include threat context if this is a new rule. -->

---

### Microsoft Tool Coverage Checklist
- [ ] Microsoft Sentinel KQL — validated for syntax, tested against data
- [ ] Defender XDR Advanced Hunting — validated, tested
- [ ] Defender for Endpoint specific guidance (MDE queries / ASR rules / Live Response) — added
- [ ] Defender for Identity guidance — added (or confirmed N/A for this technique)
- [ ] Defender for Office 365 guidance — added (or confirmed N/A)
- [ ] Defender for Cloud Apps guidance — added (or confirmed N/A)

---

### Quality Checklist
- [ ] Rule ID follows convention: `[SCOPE]-[TACTIC]-[SEQ]`
- [ ] MITRE technique ID verified at attack.mitre.org and maps correctly to the KQL
- [ ] Severity and Priority fields match the SOC priority SLA table
- [ ] KQL tested in a live Sentinel/XDR workspace — no errors
- [ ] False positive scenarios documented with specific mitigations
- [ ] Tuning guidance documented — exclusions reference watchlist names, not hardcoded values
- [ ] Investigation guide includes timed steps with embedded KQL
- [ ] Response actions are in priority order with clear ownership
- [ ] Regulatory/sector obligations documented if applicable (PCI DSS, GDPR, NIS2, FCA, NHS DSPT, SRA)
- [ ] References include MITRE link + at least one Microsoft documentation link

---

### Testing Evidence
<!-- What data or test results confirm this rule fires on attack activity? -->
<!-- What steps did you take to confirm FPs are low? -->

---

### Review
- [ ] Reviewed by Senior Analyst or Senior SOC Engineer
- [ ] Reviewed by SOC Manager (required for all sector-specific rules and all Zero Tolerance rules)
- [ ] Sector regulatory implications reviewed

---

### Linked Items
<!-- ITSM ticket | SOAR case | Threat Intel report | Customer request -->
