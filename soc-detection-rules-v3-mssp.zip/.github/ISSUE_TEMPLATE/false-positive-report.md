---
name: False Positive Report
about: Report a false positive from an existing detection rule
title: '[FP] '
labels: false-positive
assignees: ''
---

## Alert Details

**Rule ID:**
**Rule Name:**
**Customer (internal reference):**
**Alert Date/Time:**
**Frequency:** One-off | Daily | Multiple times per day (specify count):
**MS Tool:** Sentinel | Defender XDR | MDE | MDI | MDO | MCAS

---

## False Positive Description

**What legitimate activity triggered the alert?**
<!-- Be specific: process name and path, account name and role, IP address, business context -->

**Evidence confirming this is a false positive:**
<!-- E.g. Process hash matching a known vendor binary, business justification from line manager, IT ticket authorising the activity -->

---

## Proposed Suppression

**Exact suppression to add:**
<!-- Be as narrow as possible. Example: "Add process hash abc123 to GEN-IA-001-Exclusions watchlist" — NOT "Suppress all cmd.exe from Office applications" -->

**Suppression type:** Watchlist entry | Query exclusion | Sentinel suppression rule

**Expiry date:** <!-- Maximum 90 days from today — enter a specific date -->

---

## Risk Assessment

**Could this suppression allow a genuine attack to bypass detection?**
<!-- Analyst must consider: if the suppressed scenario were used by an attacker, would we miss it? -->

**Alternative detection coverage:**
<!-- Is there another rule that would still detect a real attack in this suppressed scenario? -->

---

## Approvals Required

| Role | Name | Approved | Date |
|------|------|---------|------|
| Analyst | | ☐ | |
| Senior Analyst | | ☐ | |
| SOC Manager (required for Zero Tolerance rules: GEN-IM-001, GEN-DE-001, GEN-CA-001) | | ☐ | |
