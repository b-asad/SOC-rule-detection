---
name: New Detection Rule Request
about: Request a new detection rule for the MSSP baseline
title: '[NEW RULE] '
labels: new-rule
assignees: ''
---

## Rule Details

**Proposed Rule Name:**
**MITRE Tactic:**
**MITRE Technique ID and Name:**
**Target Sector:** Generic | Retail | Healthcare | Financial Services | Government | Education | Manufacturing | Legal | Technology | Energy & Utilities
**Proposed Severity:** Critical | High | Medium | Low
**Proposed Priority:** P1 | P2 | P3 | P4

## Target Microsoft Tools
<!-- Check all that apply for this detection -->
- [ ] Microsoft Sentinel
- [ ] Defender XDR (Advanced Hunting / Custom Detections)
- [ ] Defender for Endpoint
- [ ] Defender for Identity
- [ ] Defender for Office 365
- [ ] Defender for Cloud Apps

## Required Log Sources
<!-- What data connectors / tables are needed? Are they already connected in all customer environments? -->

## Threat Scenario
<!-- Describe the attack this rule should detect. Include real-world examples, threat actor names, or recent incident context if available. -->

## Detection Logic
<!-- Provide a starting point for the KQL — this can be pseudo-code or a draft query. The analyst writing the rule will refine it. -->

```kql
// Draft detection logic here
```

## Business Justification
<!-- Why is this rule needed now? Link to: recent incident, threat intel report, customer request, regulatory requirement, or red team finding. -->

## Sector-Specific Context
<!-- What specific impact does this threat have in the target sector? Any regulatory notification obligations if this fires? -->

## False Positive Risk
<!-- What legitimate activity might trigger this rule? How should it be tuned? -->
